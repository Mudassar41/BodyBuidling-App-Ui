class string{


  static String homepage_title='Home Page';

}