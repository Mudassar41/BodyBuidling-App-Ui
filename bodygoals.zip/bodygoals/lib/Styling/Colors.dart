

import 'package:flutter/material.dart';

class color{


  color._();

  static const Color Blue=  Color(0xFF37b2f8);
  static const Color Grey=  Color(0xFFbdbdbd);
  static const Color Black=Color(0xFF000000);
  static const Color Red=Color(0xFFfa5a5a);
  static const Color Greydark=Color(0xFF57595d);
}