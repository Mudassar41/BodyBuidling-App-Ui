package body.goals.bodygoals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
